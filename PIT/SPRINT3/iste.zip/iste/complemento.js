function showLoginForm() {
    var loginForm = document.getElementById("loginForm");
    loginForm.style.display = "block";
}

